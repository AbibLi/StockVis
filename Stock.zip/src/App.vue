<script setup lang="ts">
</script>

<template>
  <div class="app">
    <router-view></router-view>
  </div>
</template>

<style>
*{
  margin: 0;
  padding: 0;
  list-style: none;
  text-decoration: none;
  box-sizing: border-box;
}
</style>
